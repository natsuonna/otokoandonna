 $(function() {
$( ".beauty" ).draggable();
});